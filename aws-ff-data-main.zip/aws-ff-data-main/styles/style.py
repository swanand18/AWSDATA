import streamlit as st

def apply_custom_styles(font_family="Open Sans", font_size="12px"):
    st.markdown(
        f"""
        <style>
        html, body, [class*="css"] {{
            font-family: '{font_family}', sans-serif;
            font-size: {font_size};
        }}

        /* Target all input widgets */
        .stTextInput > div > div > input,
        .stSelectbox > div > div > div > div,
        .stMultiselect > div > div > div,
        .stButton > button,
        .stNumberInput > div > div > input,
        .stDateInput > div > div > input,
        .stRadio > div > div > label,
        .stCheckbox > div > label,
        .stSlider > div > div > div {{
            font-family: '{font_family}', sans-serif;
            font-size: {font_size};
        }}

        /* Optional: Make buttons tighter */
        .stButton > button {{
            padding: 0.4em 1em;
            font-size: {font_size};
            border-radius: 8px;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )
